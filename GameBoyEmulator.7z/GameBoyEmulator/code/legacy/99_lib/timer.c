/**
 ******************************************************************************
 * @file    timer.c
 * @author  Bellino Francesco
 * @brief   Timer source code.
 *
 ******************************************************************************
 */

#include "../98_include/timer.h"

void timer_init()
{

}

void timer_tick()
{

}

/**
 ******************************************************************************
 * @file    ppu.c
 * @author  Bellino Francesco
 * @brief   PPU source code.
 *
 ******************************************************************************
 */

#include "../98_include/ppu.h"

void ppu_init()
{

}

void ppu_tick()
{

}

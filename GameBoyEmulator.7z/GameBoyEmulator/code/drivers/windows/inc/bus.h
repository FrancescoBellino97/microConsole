/**
 ******************************************************************************
 * @file    bus.h
 * @author  Bellino Francesco
 * @brief   TODO
 *
 *
 ******************************************************************************
 */

#ifndef BUS_H
#define BUS_H


/** INCLUDES **/


/** DEFINES **/


/** PUBLIC FUNCTIONS **/
void tmp();


#endif

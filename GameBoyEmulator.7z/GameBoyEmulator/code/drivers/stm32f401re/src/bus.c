/**
 ******************************************************************************
 * @file    bus.c
 * @author  Bellino Francesco
 * @brief   TODO
 *
 ******************************************************************************
 */


#include "bus.h"
#include <stdio.h>

void tmp()
{
	printf("STM32F401RE\n");
}

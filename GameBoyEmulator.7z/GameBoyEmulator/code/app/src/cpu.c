/**
 ******************************************************************************
 * @file    cpu.c
 * @author  Bellino Francesco
 * @brief   CPU source code.
 *
 ******************************************************************************
 */

#include "cpu.h"

/**
  * @brief  TODO add description
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t cpu_init()
{
	return NO_ERRORS;
}

/**
  * @brief  TODO add description
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t cpu_run()
{
	return NO_ERRORS;
}

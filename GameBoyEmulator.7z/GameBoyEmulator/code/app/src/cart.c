/**
 ******************************************************************************
 * @file    cart.c
 * @author  Bellino Francesco
 * @brief   Cartridge source code.
 *
 ******************************************************************************
 */

#include "cart.h"

#include <dirent.h>
#include <stdio.h>
#include <string.h>


/**
  * @brief  TODO add description
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t cart_init()
{
	struct dirent *entry;
	DIR *directory = NULL;
	uint8_t u8_retCode = NO_ERRORS;
	int fileIndex = 0;
	int fileIndexChosen;
	char filename[30];

	/* Open ROM directory */
	directory = opendir(ROM_DIRECTORY);
	if(directory == NULL)
	{
		u8_retCode = CART_INIT_ERROR;
		printf("Unable to open directory %s\n", ROM_DIRECTORY);
	}

	/* Scan directory */
	if(u8_retCode == NO_ERRORS)
	{
		/* Scanning */
		while ((entry = readdir(directory)) != NULL)
		{
			/* Skip first 2 entries . and .. */
			if (entry->d_name[0] != '.')
			{
				fileIndex++;
				printf("%d) %s\n", fileIndex, entry->d_name);
			}
		}

		/* Directory empty check */
		if(fileIndex == 0)
		{
			u8_retCode = CART_INIT_ERROR;
			printf("Directory %s is empty\n", ROM_DIRECTORY);
		}
		else
		{
			/* Get file index */
			printf("Choose a files (enter the number): ");
			scanf("%d", &fileIndexChosen);

			/* Check if file index exists */
			if(fileIndexChosen > fileIndex)
			{
				u8_retCode = CART_INIT_ERROR;
				printf("File not found\n");
			}
			else
			{
				/* Re-open directory to scan until file index chosen */
				closedir(directory);
				directory = opendir(ROM_DIRECTORY);
				for(uint8_t i=0; i<fileIndexChosen; i++)
				{
					entry = readdir(directory);

					/* Skip first 2 entries . and .. */
					if (entry->d_name[0] == '.')
					{
						i--;
					}
				}

				/* Get file name */
				strcpy(filename, entry->d_name);
				printf("File chosen: %s\n", filename);
			}
		}
	}
	closedir(directory);



	/* Open ROM file */

	/* Check ROM validity */



	return u8_retCode;
}

/**
  * @brief  TODO add description
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t cart_run()
{
	return NO_ERRORS;
}

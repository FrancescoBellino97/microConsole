/**
 ******************************************************************************
 * @file    main.c
 * @author  Bellino Francesco
 * @brief   Main app source code.
 *
 ******************************************************************************
 */

#include "emu.h"
#include "cart.h"
#include "cpu.h"
#include "ui.h"


/**
  * @brief  Initialize components
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t emu_init()
{
	uint8_t u8_retCode = NO_ERRORS;

	/* Initialize CART component */
	u8_retCode = cart_init();

	if(u8_retCode == NO_ERRORS)
	{
		/* Initialize CPU component */
		u8_retCode = cpu_init();
	}

	if(u8_retCode == NO_ERRORS)
	{
		/* Initialize UI component */
		u8_retCode = ui_init();
	}

	return u8_retCode;
}

/**
  * @brief  TODO add description
  * @param  argc:		number of arguments passed
  * 		**argv:		pointer to the arguments passed
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t emu_run()
{
	return NO_ERRORS;
}

/**
 ******************************************************************************
 * @file    main.c
 * @author  Bellino Francesco
 * @brief   Main app source code.
 *
 ******************************************************************************
 */

#include <stdio.h>

#include "common.h"
#include "emu.h"


static void print_error_code(uint8_t u8_errorCode);

/**
  * @brief  Main app that call the emulation function
  * @param  argc:		number of arguments passed
  * 		**argv:		pointer to the arguments passed
  * @retval int:		0 if no error, otherwise the code error
  */
int main(void)
{
	uint8_t u8_retCode = NO_ERRORS;

	/* TODO Necessary to disable buffer on Eclipse console */
	setbuf(stdout, NULL);

	/* Initialize EMU component */
	u8_retCode = emu_init();

	if(u8_retCode == NO_ERRORS)
	{
		/* Run EMU component */
		u8_retCode = emu_run();
	}

	print_error_code(u8_retCode);

	/* Return Error Code */
	return (int) u8_retCode;
}

/**
  * @brief  Print a message for the error code received
  * @param  u8_errorCode:	error code defined in common.h
  * @retval None
  */
static void print_error_code(uint8_t u8_errorCode)
{
	switch(u8_errorCode)
	{
	case NO_ERRORS:
		printf("No errors\n");
		break;
	case CART_INIT_ERROR:
		printf("Cartridge initialization error\n");
		break;
	case CPU_INIT_ERROR:
		printf("CPU initialization error\n");
		break;
	case UI_INIT_ERROR:
		printf("User Interface initialization error\n");
		break;
	default:
		printf("Unknown error\n");
		break;
	}
}

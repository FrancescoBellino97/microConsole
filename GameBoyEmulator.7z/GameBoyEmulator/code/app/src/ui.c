/**
 ******************************************************************************
 * @file    ui.c
 * @author  Bellino Francesco
 * @brief   User Interface source code.
 *
 ******************************************************************************
 */

#include "ui.h"

/**
  * @brief  TODO add description
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t ui_init()
{
	return NO_ERRORS;
}

/**
  * @brief  TODO add description
  * @param  None
  * @retval uint8_t:	0 if no errors, -1 otherwise
  */
uint8_t ui_run()
{
	return NO_ERRORS;
}

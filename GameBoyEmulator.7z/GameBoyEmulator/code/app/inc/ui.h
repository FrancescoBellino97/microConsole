/**
 ******************************************************************************
 * @file    ui.h
 * @author  Bellino Francesco
 * @brief   User Interface header file.
 *
 *
 ******************************************************************************
 */

#ifndef UI_H
#define UI_H


/** INCLUDES **/
#include "common.h"


/** DEFINES **/

/** PUBLIC FUNCTIONS **/
uint8_t ui_init();
uint8_t ui_run();


#endif

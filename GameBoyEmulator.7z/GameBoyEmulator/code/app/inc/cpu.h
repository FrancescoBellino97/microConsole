/**
 ******************************************************************************
 * @file    cpu.h
 * @author  Bellino Francesco
 * @brief   CPU header file.
 *
 *
 ******************************************************************************
 */

#ifndef CPU_H
#define CPU_H


/** INCLUDES **/
#include "common.h"

/** DEFINES **/

/** PUBLIC FUNCTIONS **/
uint8_t cpu_init();
uint8_t cpu_run();


#endif

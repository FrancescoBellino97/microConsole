/**
 ******************************************************************************
 * @file    cart.h
 * @author  Bellino Francesco
 * @brief   Cartridge header file.
 *
 *
 ******************************************************************************
 */

#ifndef CART_H
#define CART_H


/** INCLUDES **/
#include "common.h"

/** DEFINES **/
#define ROM_DIRECTORY	"../roms/"

/** PUBLIC FUNCTIONS **/
uint8_t cart_init();
uint8_t cart_run();


#endif

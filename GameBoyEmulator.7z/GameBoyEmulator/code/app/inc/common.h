/**
 ******************************************************************************
 * @file    common.h
 * @author  Bellino Francesco
 * @brief   Common header file.
 *
 *
 ******************************************************************************
 */

#ifndef COMMON_H
#define COMMON_H


/** INCLUDES **/
#include <stdint.h>


/** ERROR CODES **/
#define	NO_ERRORS			0
#define	CART_INIT_ERROR		1
#define	CPU_INIT_ERROR		2
#define	UI_INIT_ERROR		3


#endif
